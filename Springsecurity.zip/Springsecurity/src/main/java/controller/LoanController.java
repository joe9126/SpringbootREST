package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import model.Loans;
import model.Users;
import repository.LoansRepository;
import repository.UsersRepository;
import service.UserService;

@RestController
@RequestMapping("/loans/users")

public class LoanController {
	   public static final Logger logger = LoggerFactory.getLogger(RestController.class);
	@Autowired 
	UsersRepository user_repository;
	
	@GetMapping(value="/allusers")
	public List<Users> getAll(){
		return user_repository.findAll();
	}
	
	
	@Autowired
	LoansRepository loan_repository;
	
	@GetMapping(value="/getloans")
	public List<Loans> getLoans() {
		return loan_repository.findAll();
	}
	
	@RequestMapping(value="/request", method=RequestMethod.POST)
	public List<Loans> postLoan(@RequestBody Loans loan, UriComponentsBuilder ucBuilder){
		loan_repository.save(loan);
		return loan_repository.findAll();
	}
	 
	UserService userService;
	
	@RequestMapping (value="/createuser", method=RequestMethod.POST)
	public ResponseEntity<?> createUser(@RequestBody Users user,UriComponentsBuilder ucBuilder ){
	logger.info("Creating User:{}", user);
		if(userService.isUserExist(user)) {
			 logger.error("Unable to create user. User with username {} already exists", user.getLast_name());
		}
		else {
			userService.saveUser(user); 
			HttpHeaders headers=new HttpHeaders();
			headers.setLocation(ucBuilder.path("/api/user/{id}").buildAndExpand(user.getId()).toUri());
			return new ResponseEntity<String>( headers, HttpStatus.CREATED);
		}
		return null;
	}
	
}
