package model;

import java.sql.Date;
import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Loans {

	@Id
	@GeneratedValue
	@Column(name="loan_code")
	private Integer loan_code;
	
	@Column(name="transaction_id")
	private String transaction_id;
	
	@Column(name="amount")
	private Long amount;
	
	@Column(name="interest")
	private Long interest;
	
	@Column(name="loan_date")
	private Date loan_date;
	
	@Column(name="due_date")
	private Date loan_due_date;
	
	
	public Loans() {
		
	   }


	public void setLoan_code(Integer loan_code) {
		this.loan_code = loan_code;
	}
	

	public String getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}
	public int getLoan_code() {
		return loan_code;
	}
	public void setLoan_code(int loan_code) {
		this.loan_code = loan_code;
	}
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	public Long getInterest() {
		return interest;
	}
	public void setInterest(Long interest) {
		this.interest = interest;
	}
	public Date getLoan_date() {
		return loan_date;
	}
	public void setLoan_date(Date loan_date) {
		this.loan_date = loan_date;
	}
	public Date getLoan_due_date() {
		return loan_due_date;
	}
	public void setLoan_due_date(Date loan_due_date) {
		this.loan_due_date = loan_due_date;
	}
	
	
	
}
