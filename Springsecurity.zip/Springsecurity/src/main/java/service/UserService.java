package service;

import java.util.List;

import org.springframework.stereotype.Component;
 

import model.Users;

@Component

public interface UserService {
	Users findById(long id);
 Users findbyName(String username);
 void saveUser(Users user);
 void updateUser(Users user);
 
 List<Users > findAllusers();
 
 void deleteAllUsers();
 boolean isUserExist(Users user);
 
void deleteUserById(long id);
}
