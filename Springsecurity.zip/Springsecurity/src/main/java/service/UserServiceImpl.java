package service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.stereotype.Service;

import model.Users;

@Service

public class UserServiceImpl implements UserService{

	private static final AtomicLong counter=new AtomicLong();
	
	private static List<Users> users;
	
	static {
		users=populateDummyUsers();
	}
	
	@Override
	public Users findById(long id) {
		for(Users user: users) {
			if(user.getId()==id) {
				return user;
			}
		}
		return null;
	}

	@Override
	public Users findbyName(String username) {
		for(Users user: users) {
			if(user.getLast_name().equalsIgnoreCase(username)) {
				return user;
			}
		}
		return null;
	}

	@Override
	public void saveUser(Users user) {
		user.setId(counter.incrementAndGet()); 
		
	}

	@Override
	public void updateUser(Users user) {
		int index=users.indexOf(user);
		users.set(index, user);
		
	}

	public void deleteUserById(long id) {
		
		for(Iterator<Users>  iterator=users.iterator();iterator.hasNext();) {
			Users user=iterator.next();
			if(user.getId()==id) {
				iterator.remove();
			}
		}
		
	}

	@Override
	public List<Users> findAllusers() {
		 return users;
	}

	@Override
	public void deleteAllUsers() {
		users.clear();
		
	}

	@Override
	public boolean isUserExist(Users user) {
		 
		return findbyName(user.getLast_name())!=null;
	}
	
	private static List<Users> populateDummyUsers(){
        List<Users> users = new ArrayList<Users>();
        users.add(new Users(counter.incrementAndGet(),"Sam","sam@gmail","dan","male","10.1.2.100","sam123","active"));
        users.add(new Users(counter.incrementAndGet(),"Tom","tom@gmail","dan","male","10.1.2.100","sam123","active"));
        users.add(new Users(counter.incrementAndGet(),"Jerome","jerome@gmail","dan","male","10.1.2.100","sam123","active"));
        users.add(new Users(counter.incrementAndGet(),"Silvia","silvia@gmail","dan","male","10.1.2.100","sam123","active"));
        return users;
    }

}
